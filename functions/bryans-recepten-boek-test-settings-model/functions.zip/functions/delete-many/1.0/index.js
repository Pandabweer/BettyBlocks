import templayed from "../../utils/templayed";

async function queryRecords(modelName, where, take, count = false) {
  const getCountQuery = `
    query {
      all${modelName} (${where}take: ${take}) {
        ${count ? "totalCount" : "results { id }"}
      }
    }
  `;

  const { data, errors } = await gql(getCountQuery);

  if (errors) {
    throw errors;
  }

  return data[`all${modelName}`][count ? "totalCount" : "results"];
}

const deleteAllWithLimit = async ({
  model: { name: modelName },
  numberOfRecordsToDelete,
  filter,
  filterVariables,
}) => {
  if (numberOfRecordsToDelete <= 0 && numberOfRecordsToDelete != null) {
    throw new Error("Amount of records cannot be lower than or equal to 0");
  }

  const varMap = filterVariables.reduce((previousValue, currentValue) => {
    previousValue[currentValue.key] = currentValue.value;
    return previousValue;
  }, {});

  const where = filter ? `where: { ${templayed(filter || "")(varMap)} }, ` : "";
  const totalCount = await queryRecords(modelName, where, 1, true);

  const realAmtToDelete = numberOfRecordsToDelete
    ? numberOfRecordsToDelete > totalCount
      ? totalCount
      : numberOfRecordsToDelete
    : totalCount;
  const batchesCount = Math.ceil(realAmtToDelete / 200);

  for (let index = 1; index - 1 < batchesCount; index += 1) {
    const take = index * 200 > realAmtToDelete ? realAmtToDelete % 200 : 200;

    if (take == 0) {
      break;
    }

    const collectionResult = await queryRecords(modelName, where, take);
    const ids = collectionResult.map((item) => item.id);

    const deleteMutation = `
      mutation($input: ${modelName}Input) {
        deleteMany${modelName}(input: $input) {
          id
        }
      }
    `;

    const { errors } = await gql(deleteMutation, { input: { ids } });
    if (errors) {
      throw errors;
    }
  }

  return {
    result: `${realAmtToDelete} records from ${modelName} have been deleted`,
  };
};

export default deleteAllWithLimit;
